$(document).ready(function () {

    var thisPanel = $('.main-panel');



    // 获取绑定信息
    var getBindStatus = function () {
        // thisPanel.ajaxLoading(true);
        // AccountCtrl.request('GET_BIND_STATUS', {
        //     success: function (res) {
        //         if (res.error == 0) {
        //             initSecurityList(res.data);
        //         }
        //         if (res.error == 1) {
        //             if (noAlertMsg(res)) {
        //                 AlertUtils.alert({
        //                     icon: 'error',
        //                     content: res.message
        //                 });
        //             }
        //         }
        //     },
        //     complete: function () {
        //         thisPanel.ajaxLoading(false);
        //     }
        // });
    };

    // 安全列表
    var initSecurityList = function (data) {
        var t = $(thisPanel).find('.security-list');
        var level = 0;
        var text = ['无', '危险', '低', '中', '高'];

        var security = t.find('[data-type="security"]');
        var googleAuthenticator = t.find('[data-type="googleAuthenticator"]');
        var birthday = t.find('[data-type="birthday"]');
        var cellphone = t.find('[data-type="cellphone"]');
        var qq = t.find('[data-type="qq"]');
        var email = t.find('[data-type="email"]');

        if (data.isBindWithdrawName) {
            level++
            t.find('[data-type="withdrawName"]').addClass('safe');
            t.find('[data-command="setup-withdraw-name"]').html('已绑定').addClass('disabled');
        }

        if (data.isBindWithdrawPassword) {
            level++
            t.find('[data-type="withdrawPassword"]').addClass('safe');
            t.find('[data-command="setup-withdraw-pwd"]').html('已设置').addClass('disabled');
            t.find('[data-command="mod-withdraw-pwd"]').removeClass('disabled');
        }

        if (data.isBindCard) {
            level++
            t.find('[data-type="card"]').addClass('safe');
            t.find('[data-command="bind-withdraw-card"]').html('已绑定').addClass('disabled');
            t.find('[data-command="add-withdraw-card"]').removeClass('disabled');
        }

        if (data.isBindSecurity) {
            level++
            security.addClass('safe');
            security.find('.btn').html('已设置').addClass('disabled');
        }
        $('[data-field="safe"]').html( text[level] );
    };

    //谷歌验证
    var googleReg = function () {
        // //获取是否绑定谷歌验证
        // var getGoogleBindState =  function () {
        //     AccountCtrl.request('GET_GOOGLE_BIND_STATUS', {
        //         success: function (res) {
        //             if (res.error == 0) {
        //                 if( !res.data.googleBind ){
        //                     $('[data-command="switch-googleVerify"]').attr("google-state",'bind');
        //                 }else{
        //                     getGoogleState();
        //                 };
        //
        //             }else if (res.error == 1) {
        //                 if (noAlertMsg(res)) {
        //                     AlertUtils.alert({
        //                         icon: 'error',
        //                         content: res.message
        //                     });
        //                 };
        //             };
        //         }
        //     });
        // };
        // //获取是否开启谷歌验证状态
        // var getGoogleState =  function () {
        //     AccountCtrl.request('GET_GOOGLE_LOGIN_STATUS', {
        //         success: function (res) {
        //             if (res.error == 0) {
        //                 if( res.data.googleLogin ){
        //                     $('[data-command="switch-googleVerify"]').attr("google-state",'open');
        //                 }else{
        //                     $('[data-command="switch-googleVerify"]').attr("google-state",'close');
        //                 };
        //
        //             }else if (res.error == 1) {
        //                 if (noAlertMsg(res)) {
        //                     AlertUtils.alert({
        //                         icon: 'error',
        //                         content: res.message
        //                     });
        //                 };
        //             };
        //         }
        //     });
        // };
        //
        // getGoogleBindState();
    };

    thisPanel.find('[data-command="mod-login-pwd"]').click(function () {
        ModLoginPwdModal.init(function () {
            MainCtrl.logout({
                success: function (res) {
                    if (res.error == 0) {
                        window.location.href = '/login.html';
                    }
                }
            });
        });
    });

    thisPanel.find('[data-command="bind-security"]').click(function () {
        BindSecurityModal.init(function () {
            getBindStatus();
        });
    });

    thisPanel.find('[data-command="setup-withdraw-name"]').click(function () {
        SetupWithdrawNameModal.init(function () {
            getBindStatus();
        });
    });

    thisPanel.find('[data-command="setup-withdraw-pwd"]').click(function () {
        SetupWithdrawPwdModal.init(function () {
            getBindStatus();
        });
    });

    thisPanel.find('[data-command="mod-withdraw-pwd"]').click(function () {
        ModWithdrawPwdModal.init();
    });

    //绑定谷歌验证器
    thisPanel.find('[data-command="bind-googleVerify"]').click(function () {
        BindGoogleModal.init(function(){
            googleReg();
        });
    });
    //开启、关闭谷歌验证器
    thisPanel.find('[data-command="switch-googleVerify"]').click(function () {
        var state = $(this).attr("google-state");

        if( state=="bind" ){
            BindGoogleModal.init(function(){
                googleReg();
            });
        }else if( state=="close" ){
            ChangeGoogleStateModal.init(function(){
                googleReg();
            },true);
        }else{
            ChangeGoogleStateModal.init(function(){
                googleReg();
            },false);
        };

    });

    thisPanel.find('[data-command="bind-withdraw-card"]').click(function () {
        BindWithdrawCardModal.init(function () {
            getBindStatus();
        });
    });

    thisPanel.find('[data-command="add-withdraw-card"]').click(function () {
        BindWithdrawCardModal.init();
    });

    // 初始化方法
    googleReg();
    getBindStatus();


    //获取百家乐游戏
    var listinit = function(){
        GamesimulationCtrl.request('LIST_ALL_GAMES', {
            success: function (res) {
                if (res.error == 0){
                    var data = res.data.gameList;
                    $.each(data, function (i, v) {
                        status = v.status;
                        var list = $(".all-transfer")
                        if(status!=0){
                            Tel = '<div data-id="'+v.id+'" class="col-md-2">\
										<div class="name">'+v.name+'</div>\
										<div class="money">游戏未开通</div>\
									</div>'
                            list.append(Tel);
                        }else{
                            Tel = '<div data-id="'+v.id+'" class="col-md-2">\
										<div class="name">'+v.name+'</div>\
										<div class="money">余额:<span data-global="queryBalance">0</span>元</div>\
									</div>'
                            list.append(Tel);
                            querybalance(v.id);
                        }

                    });
                }
                if (res.error == 1) {
                    if (noAlertMsg(res)) {
                        AlertUtils.alert({
                            icon: 'error',
                            content: res.message
                        });
                    }
                }
            },
        });
    }

    //查询账户余额
    var querybalance = function(id){
        var refreshBtn  = $('[data-id="'+id+'"]').find(".refresh");
        GamesimulationCtrl.request('QUERY_BALANCE', {
            data:{gameId:id},
            beforeSend: function () {
                refreshBtn.addClass('loading');
            },
            success: function (res) {
                money = res.data.account_balance;
                $('[data-id="'+id+'"]').find('[data-global="queryBalance"]').text(money)
            },
            complete: function () {
                refreshBtn.removeClass('loading');
            }
        })
    };

    // listinit();


    //获取奖金组

    var allCode = function(){
        var GameLotteryAccount = store.get('PRIVATE:GameLotteryAccount');
        var GameLotteryInfoList = store.get('PUBLIC:GameLotteryInfoList');
        var $codebox = $('.all-code').find('.code-box')
        var code = GameLotteryAccount.code;
        $.each(GameLotteryInfoList, function (i, v) {
            if( v.liDownCode=='0'){
                var newcode = code + v.floatBonus;
            }else{
                var newcode = v.downCode;
            }
            var $tel = '<div class="item col-xs-1-8"><div class="name">'+v.showName+'</div><div class="code">'+newcode+'</div></div>'
            if(v.showName!="东京时时彩"&&v.showName!="韩国时时彩")
                $codebox.append($tel);
        });
    }
    allCode();

    $('.all-code .title span').click(function(){
        var typestyle = $(this).html();
        if(typestyle=="查看全部"){
            $(this).html("收起");
            $('.main-panel .all-code').height('433');
        }else{
            $(this).html("查看全部");
            $('.main-panel .all-code').height('191');
        }
    })
});