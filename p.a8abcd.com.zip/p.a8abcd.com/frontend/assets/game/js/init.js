var GameLoop = function () {
    var g_lottery; // 彩票游戏

    var loadData = function () {
        var url = AppRoute.PATH + AppRoute.WebAjax.PATH + AppRoute.WebAjax.LOOP_GAME_LOTTERY;
        var data = {lottery: g_lottery};
        HttpRequest({
            url: url,
            data: data,
            success: function (res) {
                if (res.code == 0) {
                    handleData(res.content,g_lottery);
                }else {
                    if (res.code == 99) {
                        store.clear(); // 清空数据
                        window.location.href = '/user/login';
                    }
                    AlertUtils.alert({
                        icon: 'error',
                        content: res.msg
                    });
                }
            }
        });
    };

    var handleData = function (data,g_lottery) {
        store.transact('PRIVATE:MsgCount', function (value) {
            value = data.msgCount;
        });
        store.transact('PRIVATE:GameLotteryAccount', function (value) {
            value.money = data.money;
        });
        updateDataGlobal();

        if (data.gameOpenCode) {
            LotteryOpenCode.refresh(data.gameOpenCode);
        }
        if (data.hasNewNotice) {
            LotteryOpenNotice.refresh(g_lottery);
        }
    };

    var init = function (lottery) {
        g_lottery = lottery;
        setInterval(loadData, 8000);
    };

    return {
        init: init
    }

}();

var getLotteryType = function (v) {
    if (v.type == 1) return 'lottery-ssc';
    if (v.type == 2) return 'lottery-11x5';
    if (v.type == 3) return 'lottery-k3';
    if (v.type == 4) return 'lottery-3d';
    if (v.type == 5) return 'lottery-kl8';
    if (v.type == 6) return 'lottery-pk10 ' + v.shortName;
};

var lotteryName = location.search.substring(1);
if (!lotteryName) {
    lotteryName = 'ln11x5';
}

var GameLotteryInfoList = store.get('PUBLIC:GameLotteryInfoList');
$.each(GameLotteryInfoList, function (i, v) {
    if (v.shortName == lotteryName) {
        // 初始化循环数据
        GameLoop.init(lotteryName);
        // 初始化开奖号码
        LotteryOpenCode.init(v);
        // 初始化开奖时间
        LotteryOpenTime.init(v);
        // 初始化彩种信息
        lottery_data.showName = v.showName;
        lottery_data.shortName = v.shortName;
        lottery_data.type = v.type;
        lottery_data.downCode = v.downCode;
        lottery_data.fenDownCode = v.fenDownCode;
        lottery_data.liDownCode = v.liDownCode;
        // 1.这里更新浮动奖金
        lottery_data.floatBonus = v.floatBonus;
        // 初始化页面信息
        $('body').addClass(getLotteryType(v));
        $('[data-field="global-name"]').html(v.showName);
        $('[data-command="trend"]').click(function () {
            window.open('trend.html?' + v.shortName);
        });
    }
});

var GameLotteryMethodList = store.get('PUBLIC:GameLotteryMethodList');
$.each(GameLotteryMethodList, function (i, v) {
    if (v.type == lottery_data.type) {
        method_data[v.methodName] = v;
    }
});

var GameLotteryConfig = store.get('PUBLIC:GameLotteryConfig');
config_data.lotteryCode = 1998;//GameLotteryConfig.sysCode;
config_data.lotteryPoint = 9.9;//GameLotteryConfig.sysPoint;
config_data.unitMoney = 1;//GameLotteryConfig.sysUnitMoney;

var GameLotteryAccount = store.get('PRIVATE:GameLotteryAccount');
account_data.lotteryCode = GameLotteryAccount.max_odds;
account_data.lotteryPoint = 9.9;//GameLotteryAccount.point;

// 初始化游戏
LotteryPlay.init();

// 初始化菜单
$(document).ready(function () {
    var lotteryMenu = $('.lottery-menu');
    var lotteryList = lotteryMenu.find('.list');
    var lotteryItem = lotteryList.find('.item');
    var toggleMenu = $('[data-toggle="lottery-menu"]');
    var thisTimer; // 鼠标滑动定时器


    lotteryItem.click(function () {
        var dataName = $(this).attr('data-name');
        if (dataName) {
            window.location.href = 'play.html?' + dataName;
        }
    });
});

// 初始化皮肤
// $(document).ready(function () {
//     var lightControl = $('.skin');
//     var themeName = store.get('ThemeName');
//     if (themeName != 'forest') {
//          store.set('ThemeName', 'default');
//     }
//     lightControl.click(function () {
//         var themeStyle = $('#theme-style');
// 		var thisTheme = $(this).attr("data-name")
//         var themeHref = 'themes/' + thisTheme + '/css/style.css';
//         if (themeStyle.length > 0) {
//             themeStyle.attr('href', themeHref);
//         } else {
//             $('head').append('<link rel="stylesheet" type="text/css" href="' + thisTheme + '" id="theme-style"/>');
//         }
//         store.set('ThemeName', thisTheme);
//     });
// });

