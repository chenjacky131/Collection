var headerTplmember =
    `
    <div class="header animated bounceInDown" id="toolbar">
        <div class="message clear">
            <!--<a class="logo lf" href="/user/game/syxw"></a>-->
            <div class="quickList lf">
                <a class="item lf" href="/user/playGame?ln11x5">A8首页</a>
                <div class="lottery_menu_switch">
                    <div class="lottery_menu">
                        <div class="container-fluid">
                            <div class="accordion" id="accordion3">
                                <div class="accordion-group">
                                    <div class="accordion-heading">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#collapse_1" href="#collapse_1" aria-expanded="true">
                                            热门彩种 <i class="icon"></i>
                                        </a>
                                    </div>
                                    <div id="collapse_1" class="accordion-body  collapse" aria-expanded="true">
                                        <div class="accordion-inner">
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--{{&#45;&#45;<a class="item lf" href="/game/lottery/play.html">彩票大厅</a>&#45;&#45;}}-->
                <!--{{&#45;&#45;<div class="item quickPort lf">快速入口&#45;&#45;}}-->
                    <!--{{&#45;&#45;<div class="personCenter lf">&#45;&#45;}}-->
                        <!--{{&#45;&#45;<div class="list lf">&#45;&#45;}}-->
                            <!--{{&#45;&#45;<a class="item lf" href="/view/activity/index.html"> <i class="icon"></i>优惠活动 </a>&#45;&#45;}}-->
                            <!--{{&#45;&#45;<a class="item lf" href="/view/about/index.html"> <i class="icon"></i>关于我们 </a>&#45;&#45;}}-->
                            <!--{{&#45;&#45;<a class="item lf" href="/view/notice/index.html"> <i class="icon"></i>系统公告 </a>&#45;&#45;}}-->
                            <!--{{&#45;&#45;<a class="item lf" href="/view/help-center/index.html"> <i class="icon"></i>帮助中心 </a>&#45;&#45;}}-->
                            <!--{{&#45;&#45;<a class="item lf" href="/view/download/index.html" target="_blank">app下载</a>&#45;&#45;}}-->
                        <!--{{&#45;&#45;</div>&#45;&#45;}}-->
                    <!--{{&#45;&#45;</div>&#45;&#45;}}-->
                <!--{{&#45;&#45;</div>&#45;&#45;}}-->
                <!--{{&#45;&#45;<a class="item lf" href="/view/baccarat/index.html">百家乐</a>&#45;&#45;}}-->
            </div>
            <div class="messagedd rt">
                <div class="user_box lf">
                    <div class="user_img lf">
                        <img src="/frontend/assets/images/header/0.jpg" alt="">
                        <a href="/member/message-inbox.html" class="lf" data-global="msgCount">0</a>
                    </div>
                    <div data-global="username"></div>
                    <div class="personCenter lf">
                        <div class="list lf">
                            <a class="lf" href="/user/memberHome">用户中心</a>
                            <a class="lf" href="/user/memberOrder">投注记录</a>
                        </div>
                    </div>
                </div>

                <div class="moneyBox pointer lf">

                    账户余额： <span class="money" data-global="lotteryBalance">0.00</span>元<i data-command="refresh" class=" reload pointer"></i>
                    <!--{{&#45;&#45;<div class="wallet">&#45;&#45;}}-->
                        <!--{{&#45;&#45;<ul class="list">&#45;&#45;}}-->
                            <!--{{&#45;&#45;<li>总余额：<span data-global="TotalBalance">加载中</span></li>&#45;&#45;}}-->
                            <!--{{&#45;&#45;<li>GG捕鱼钱包：<a class="rt">未开通</a><span class="rt">**</span></li>&#45;&#45;}}-->
                            <!--{{&#45;&#45;<li>AG视讯钱包：<a class="rt">未开通</a><span class="rt">**</span></li>&#45;&#45;}}-->
                            <!--{{&#45;&#45;<li>KY开元棋牌钱包：<a class="rt">未开通</a><span class="rt">**</span></li>&#45;&#45;}}-->
                            <!--{{&#45;&#45;<li>DG视讯钱包：<a class="rt">未开通</a><span class="rt">**</span></li>&#45;&#45;}}-->
                            <!--{{&#45;&#45;<li>DS德胜棋牌钱包：<a class="rt">未开通</a><span class="rt">**</span></li>&#45;&#45;}}-->
                        <!--{{&#45;&#45;</ul>&#45;&#45;}}-->
                    <!--{{&#45;&#45;</div>&#45;&#45;}}-->
                </div>
                <div class="top-btn lf">
                    <!--{{&#45;&#45;<a class="item lf hover" href="/member/funds-apply-recharge.html"><i class="icon"></i> 充值</a>&#45;&#45;}}-->
                    <!--{{&#45;&#45;<a class="item lf hover" href="/member/funds-apply-withdraw.html"><i class="icon"></i> 取款</a>&#45;&#45;}}-->
                    <a class="item lf hover logout" data-command="logout"><i class="icon"></i> 退出</a>
                    <!--{{&#45;&#45;<a class="item" href="/service.html" target="_blank">&#45;&#45;}}-->
                        <!--{{&#45;&#45;<span class="text"> 在线客服</span>&#45;&#45;}}-->
                    <!--{{&#45;&#45;</a>&#45;&#45;}}-->
                    <!--{{&#45;&#45;<a class="item" href="/lines.html" target="_blank">&#45;&#45;}}-->
                        <!--{{&#45;&#45;<span class="text"> 线路检测</span>&#45;&#45;}}-->
                    <!--{{&#45;&#45;</a>&#45;&#45;}}-->
                </div>
            </div>

        </div>

    </div>
`
// 初始化皮肤
$(document).ready(function () {
    var themeName = localStorage.ThemeName;
    switchs(themeName);

    function switchs(themeName){
        if(themeName!='forest'){
            themeName = 'default';
        };

        var src = 'themes/'+themeName+'/css/style.css';
        $("#themes").attr('href',src);
        localStorage.ThemeName = themeName;
    };

    $('.skin').click(function(){
        var themeName = localStorage.ThemeName;
        if(themeName=='forest'){
            themeName = 'default';
        }else{
            themeName = 'forest';
        }
        switchs(themeName);

        //调用子iframe页面里的方法
    });

});


