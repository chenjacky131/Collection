(function () {
    $(document).ready(function(){
        /*** 右侧菜单的选中效果 ***/
        function rightMenuActive(){
            var url = location.href;
            var node = $(".person_center a");
            var arr = [
                //个人中心
                {type:0,page:'member/member-home.html'},
                {type:0,page:'member/member-card.html'},
                //投注记录==报表中心
                {type:1,page:'member/member-order.html'},
                {type:1,page:'member/member-chase.html'},
                {type:1,page:'member/member-bill.html'},
                {type:1,page:'member/member-report.html'},
                //契约下级
                {type:2,page:'member/agent-contract-lower-list.html'},
                {type:2,page:'member/agent-contract-salary-record.html'},
                {type:2,page:'member/agent-contract-dividend-stat.html'},
                {type:2,page:'member/agent-contract-dividend-record.html'},
                {type:2,page:'member/agent-contract-mime-list.html'},
                //财务管理
                {type:3,page:'member/funds-apply-recharge.html'},
                {type:3,page:'member/funds-apply-withdraw.html'},
                {type:3,page:'member/funds-recharge-record.html'},
                {type:3,page:'member/funds-withdraw-record.html'},
                //代理中心
                {type:4,page:'member/agent-team-overview.html'},
                {type:4,page:'member/agent-open-account.html'},
                {type:4,page:'member/agent-team-list.html'},
                {type:4,page:'member/agent-team-online.html'},
                {type:4,page:'member/agent-team-recharge.html'},
                {type:4,page:'member/agent-team-withdraw.html'},
                {type:4,page:'member/agent-team-bill.html'},
                {type:4,page:'member/agent-team-report.html'},
                {type:4,page:'member/agent-team-report-detail.html'},
                {type:4,page:'member/agent-team-order.html'},
                //百家乐账户
                {type:5,page:'member/funds-transfer-wallet.html'},
                {type:5,page:'member/funds-transfer-gameorder.html'},
                {type:5,page:'member/funds-transfer-gamelist.html'},
                //收件箱
                {type:6,page:'member/message-inbox.html'},
                {type:6,page:'member/message-send.html'},
            ];
            var game = [
                [
                    {name:"腾讯分分彩", keyword:"qqmin",type:1, },
                    {name:"重庆时时彩",keyword:"cqssc",type:1,state:"hot" },
                    {name:"天津时时彩",keyword:"tjssc",type:1 },
                    {name:"新疆时时彩",keyword:"xjssc",type:1,state:"new" },
                    {name:"北京时时彩",keyword:"bjssc",type:1 },
                    {name:"台湾时时彩",keyword:"twssc",type:1 },
                    {name:"幸运十分彩",keyword:"t1s600",type:1,state:"new"  },
                    {name:"河内5分彩",keyword:"t1s300",type:1,state:"new"  },
                    {name:"腾讯5分彩",keyword:"qq5fen",type:1,state:"new"  },
                    {name:"腾讯十分彩",keyword:"qq10fen",type:1,state:"new" },
                    {name:"幸运5分彩",keyword:"t1s300a",type:1,state:"new" },
                    {name:"快乐2分彩",keyword:"t1s120",type:1,state:"new" },
                    {name:"幸运分分彩",keyword:"t1s60a",type:1,statu:"new" },
                    {name:"幸运三分彩",keyword:"t1s180a",type:1,statu:"new" },
                ],
                [
                    {name:"韩国1.5分彩",keyword:"t1s90",type:2,state:"new"  },
                    {name:"新加坡30秒彩",keyword:"t1s30",type:2 },
                    {name:"美国一分彩",keyword:"t1s60",type:2,state:"hot"  },
                    {name:"东京1.5分彩",keyword:"t1s90d",type:2 },
                    {name:"新加坡2分彩",keyword:"sgssc",type:2 },
                    {name:"新德里1.5分彩",keyword:"t1s90a",type:2 },
                    {name:"俄罗斯1.5分彩",keyword:"t1s90b",type:2 },
                    {name:"印度1.5分彩",keyword:"t1s90c",type:2 },
                    {name:"缅甸3分彩",keyword:"t1s180",type:2 },
                ],
                [
                    {name:"纽约11选5",keyword:"t2s30",type:3 },
                    {name:"加拿大11选5",keyword:"t2s90",type:3,state:"hot"  },
                    {name:"山东11选5",keyword:"sd11x5",type:3,state:"new"  },
                    {name:"广东11选5",keyword:"gd11x5",type:3 },
                    {name:"江西11选5",keyword:"jx11x5",type:3 },
                    {name:"安徽11选5",keyword:"ah11x5",type:3 },
                    {name:"上海11选5",keyword:"sh11x5",type:3 },
                    {name:"辽宁11选5",keyword:"ln11x5",type:3 },
                ],
                [
                    {name:"吉隆坡快3",keyword:"t3s90",type:4 },
                    {name:"新西兰快3",keyword:"t3s120",type:4,state:"hot"  },
                    {name:"江苏快3",keyword:"jsk3",type:4,state:"new"  },
                    {name:"安徽快3",keyword:"ahk3",type:4 },
                    {name:"湖北快3",keyword:"hbk3",type:4 },
                    {name:"吉林快3",keyword:"jlk3",type:4 },
                ],
                [
                    {name:"北京快乐8",keyword:"bjkl8",type:5 },
                    {name:"台湾快乐8",keyword:"twkl8",type:5,state:"new"  },
                    {name:"韩国快乐8",keyword:"hgkl8",type:5,state:"hot"  },
                    {name:"东京快乐8",keyword:"jpkl8",type:5 },
                    {name:"新加坡快乐8",keyword:"sgkl8",type:5 },
                ],
                [
                    {name:"福彩3D",keyword:"fc3d",type:6,state:"new"  },
                    {name:"排列三",keyword:"pl3",type:6,state:"hot"  },
                    {name:"北京赛车PK拾",keyword:"bjpk10",type:6 },
                    {name:"英国120秒赛车",keyword:"t6s120",type:6 },
                    {name:"英国180秒赛车",keyword:"t6s180",type:6 },
                    {name:"幸运飞艇",keyword:"t6s300",type:6},
                ]

            ];
            for(var i=0;i<arr.length;i++){
                var bool = url.indexOf( arr[i].page );
                if( bool>0 ){
                    node.eq( arr[i].type ).addClass("active").siblings().removeClass('active');
                    return;
                };
            };

            function initLotteryMenu(){
                var url = location.href;
                if( url.indexOf('play.html')<0 ){
                    var keyword = '';
                }else{
                    keyword = url.split("");
                    var keyword = location.href.split("?")[1]||'cqssc';
                };


                for(var i=0,html='';i<game.length;i++){
                    html += `<li class="clear"><h3 class="title"></h3>`;
                    for(var j=0;j<game[i].length;j++){
                        if(keyword==game[i][j].keyword){
                            var active = "active";
                        }else{
                            var active = "";
                        };
                        html += `<a class="${active}" href="/game/lottery/play.html?${game[i][j].keyword}">${game[i][j].name}</a>`;
                    };
                    html += `</li>`;

                };
                $(".header_list .lottery_menu").html(html);
                $(".header_list .lottery_menu .title").eq(0).text('时时彩');
                $(".header_list .lottery_menu .title").eq(1).text('全天彩');
                $(".header_list .lottery_menu .title").eq(2).text('11选5');
                $(".header_list .lottery_menu .title").eq(3).text('快3');
                $(".header_list .lottery_menu .title").eq(4).text('快8');
                $(".header_list .lottery_menu .title").eq(5).text('其它彩种');
            };
            //initLotteryMenu();

        };
        /*** 头部菜单的选中效果 ***/
        function topMenuActive(){
            var url = location.href;
            var node = $(".header_list .child_item a");
            for(var i=0;i<node.length;i++){
                var href = node.eq(i).attr('href');
                var num = url.indexOf(href);
                if(num>0){
                    node.eq(i).addClass("active").siblings().removeClass('active');
                    return;
                };
            };

        };




        rightMenuActive();
        topMenuActive();
    });
    moneyBag();
    function moneyBag(){
        // /*** 钱包效果 ***/
        // $('.moneyBox').mouseenter(function(){
        //     $('.wallet').show();
        // });
        // $('.moneyBox').mouseleave(function(){
        //     $('.wallet').hide();
        // });
    }

    var toolbar = $('#toolbar');
    //点击logo进入首页
    // toolbar.find('.logo').click(function(){
    //     location.href='/index';
    // });
    // 首页
    // 退出登录

    toolbar.find('[data-command="logout"]').click(function () {
        AlertUtils.confirm({
            title: '安全退出',
            icon: 'question',
            content: '确定退出本页面吗？',
            confirmFn: function (index) {
                store.clear(); // 清空数据
                window.location.href = '/user/login';
            }
        });

    });
    // 刷新数据
    var refreshBtn = $('[data-command="refresh"]');
    refreshBtn.click(function () {
        HttpRequest({
            url: '/user/web-ajax/loop-page',
            data:{'lottery':lotteryName},
            beforeSend: function () {
                refreshBtn.addClass('loading');
            },
            success: function (res) {
                if (res.code == 0) {
                    // store.set('PRIVATE:MsgCount', res.data.msgCount);
                    store.transact('PRIVATE:Account', function (value) {
                        value.money = res.content.money;
                    });
                    store.set('PRIVATE:LotteryMethodLimit', res.content.lotteryMethodLimit);
                    LotteryPlay.lotteryMethodLimit();
                    updateDataGlobal();
                    listallgames();
                }else {
                    if (res.code == 99) {
                        store.clear(); // 清空数据
                        window.location.href = '/user/login';
                    }
                    AlertUtils.alert({
                        icon: 'error',
                        content: res.msg
                    });
                }
            },
            complete: function () {
                refreshBtn.removeClass('loading');
            }
        });
    });

    // 设置时间
    var getTime = function () {
        toolbar.find('.date-time').html(moment().format('YYYY年M月D日 HH:mm:ss dddd'));
    };
    getTime();
    setInterval(getTime, 1000);
})();


var lotteryName = location.search.substring(1);
if (!lotteryName) {
    lotteryName = 'ln11x5';
}
var loopDataGlobal = function () {
    HttpRequest({
        url: '/user/web-ajax/loop-page',
        data:{'lottery':lotteryName},
        success: function (res) {
            if (res.code == 0) {
                store.transact('PRIVATE:Account', function (value) {
                    value.money = res.content.money;
                });
                store.set('PRIVATE:LotteryMethodLimit', res.content.lotteryMethodLimit);
                LotteryPlay.lotteryMethodLimit();
                updateDataGlobal();
            }else {
                if (res.code == 99) {
                    store.clear(); // 清空数据
                    window.location.href = '/user/login';
                }
                AlertUtils.alert({
                    icon: 'error',
                    content: res.msg
                });
            }
        }
    });
};

// if (isLogin && isLoop) {
    loopDataGlobal();
    setInterval(loopDataGlobal, 10000);
// }

var updateDataGlobal = function () {
    var BalanceState = store.get('BalanceState')
    var Account = store.get('PRIVATE:Account');
    var MsgCount = store.get('PRIVATE:MsgCount');
    var GameLotteryAccount = store.get('PRIVATE:GameLotteryAccount');
    $('[data-global="username"]').html(Account.username);
    $('[data-global="msgCount"]').html(MsgCount);
    if(BalanceState != 'hide'){
        $('[data-global="lotteryBalance"]').html(Account.money);
    }
    // 账户状态
    if (MsgCount != 0) {
        $('[data-global="msgCount"]').removeClass('hide');
    }
    if (Account.type == 1) {
        $('[data-visible="agent"]').removeClass('hide');
    }
};

updateDataGlobal();

//用户图像
(function(){
    // AccountCtrl.request('LIST_FULL_INFO', {
    //     data: {
    //         showInfo: true,
    //     },
    //     success: function (res) {
    //         if (res.error == 0) {
    //             // 设置头像
    //             if (res.data&&res.data.accountInfo) {
    //                 var avatarImg = '/member/images/avatar/' + res.data.accountInfo.avatar + '.jpg';
    //                 $(".user_img").find("img").attr('src', avatarImg);
    //             }
    //         }
    //         if (res.error == 1) {
    //             if (noAlertMsg(res)) {
    //                 AlertUtils.alert({
    //                     icon: 'error',
    //                     content: res.message
    //                 });
    //             }
    //         }
    //     },
    //
    // });
})();

// 契约展示
(function () {


    /**
     * salaryType:工资配置 1:百分比返 2:间隙返 3:原平台
     * dividendType:分红配置  1:百分比返  2:原平台日分红 3:原平台契约分红
     */
    var salaryType,dividendType;
    //获取契约类型
    // ContractCtrl.request('LOAD_CONTRACT_TYPE', {
    //     success: function (res) {
    //         store.set('PRIVATE:salaryType', res.data.salaryType);
    //         store.set('PRIVATE:dividendType', res.data.dividendType);
    //     }
    // });



    var Account = store.get('PRIVATE:Account');
    if (Account.type == 1) {
        (function(){
            ContractCtrl.request('LOAD_CONTRACT_STATUS', {
                success: function (res) {
                    //var res = {"error":0,"code":null,"message":"请求成功","data":{"dividendStatus":1,"salaryStatus":1}}
                    if (res.error == 0) {
                        buildData(res.data);
                    }
                }
            });

            var buildData = function (data) {
                if (data.salaryStatus!=undefined) {
                    var status = data.salaryStatus;
                    $('[data-visible="contract"]').removeClass('hide');
                    if (status == 0) {
                        if (!localStorage.isShowContractAlert) {
                            AlertUtils.confirm({
                                icon: 'question',
                                content: '您有新的契约需要同意，是否立即处理？',
                                confirmFn: function () {
                                    window.location.href = '/member/agent-contract-mime-list.html';
                                }
                            });
                            localStorage.isShowContractAlert = true;
                        }
                    }

                    if (status == 1) {
                        $('[data-visible="contract-lower"]').removeClass('hide');
                        $('[data-visible="salary-contract"]').removeClass('hide');
                    }
                }
                if (data.dividendStatus!=undefined) {
                    var status = data.dividendStatus;
                    $('[data-visible="contract"]').removeClass('hide');
                    if (status == 0) {
                        if (!localStorage.isShowContractAlert) {
                            AlertUtils.confirm({
                                icon: 'question',
                                content: '您有新的契约需要同意，是否立即处理？',
                                confirmFn: function () {
                                    window.location.href = '/member/agent-contract-mime-list.html';
                                }
                            });
                            localStorage.isShowContractAlert = true;
                        }
                    }
                    if (status == 1) {
                        $('[data-visible="contract-lower"]').removeClass('hide');
                        $('[data-visible="dividend-contract"]').removeClass('hide');
                    }
                }
            };
        })();


        (function(){
            SimulationCtrl.request('LOAD_CONTRACT_STATUS', {
                success: function (res) {
                    console.log(res);
                    if (res.error == 0) {
                        buildData(res.data);
                    }
                }
            });

            var buildData = function (data) {
                if (data.salaryStatus!=undefined) {
                    var status = data.salaryStatus;
                    $('[data-visible="simulation"]').removeClass('hide');
                    if (status == 0) {
                        if (!localStorage.isShowContractAlert) {
                            AlertUtils.confirm({
                                icon: 'question',
                                content: '您有新的棋牌契约需要同意，是否立即处理？',
                                confirmFn: function () {
                                    window.location.href = '/member/simulation-contract-mime-list.html';
                                }
                            });
                            localStorage.isShowContractAlert = true;
                        };
                    };

                    if (status == 1) {
                        $('[data-visible="simulation-lower"]').removeClass('hide');
                        $('[data-visible="salary-simulation"]').removeClass('hide');
                    };
                };

            };

        })();

    };
})();