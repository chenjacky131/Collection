// var headerTplmember =
//     `
// <div class="header animated bounceInDown" id="toolbar">
//
// <div class="message clear" >
//
//     <a class="logo lf" href="/index.html"></a>
//     <div class="quickList lf">
//         <a class="item lf" href="/index.html">首页</a>
//         <a class="item lf" href="/game/lottery/play.html">彩票大厅</a>
//         <div class="item quickPort lf">快速入口
//             <div class="personCenter lf">
//                 <div class="list lf">
//                     <a class="item lf" href="/view/activity/index.html"> <i class="icon"></i>优惠活动 </a>
//                     <a class="item lf" href="/view/about/index.html"> <i class="icon"></i>关于我们 </a>
//                     <a class="item lf" href="/view/notice/index.html"> <i class="icon"></i>系统公告 </a>
//                     <a class="item lf" href="/view/help-center/index.html"> <i class="icon"></i>帮助中心 </a>
//                     <a class="item lf" href="/view/download/index.html" target="_blank">app下载</a>
//                 </div>
//             </div>
//         </div>
//         <a class="item lf" href="/view/baccarat/index.html">百家乐</a>
//     </div>
//     <div class="messagedd lf">
//         <div class="user_box lf">
//             <div class="user_img lf">
//                 <img src="/member/images/avatar/0.jpg" alt="">
//                 <a href="/member/message-inbox.html" class="lf" data-global="msgCount">0</a>
//             </div>
//             <div data-global="username">加载中</div>
//             <div class="personCenter lf">
//                 <div class="list lf">
//                     <a class="lf" href="/member/member-home.html">用户中心</a>
//                     <a class="lf" href="/member/member-order.html">投注记录</a>
//                     <a class="lf hide" data-visible="contract" href="/member/agent-contract-mime-list.html">契约中心</a>
//                     <a class="lf hide" data-visible="simulation" href="/member/simulation-contract-mime-list.html">棋牌契约</a>
//                     <a class="lf" href="/member/funds-apply-recharge.html">财务管理</a>
//                     <a class="lf hide" href="/member/agent-team-overview.html" data-visible="agent">代理中心</a>
//                     <a class="lf" href="/member/funds-transfer-wallet.html">百家乐账户</a>
//                     <a class="lf" href="/member/message-inbox.html">收件箱</a>
//                 </div>
//             </div>
//         </div>
//
//         <div class="moneyBox pointer lf">
//
//             账户余额： <span class="money" data-global="lotteryBalance">0</span>元<i data-command="refresh" class=" reload pointer"></i>
//             <div class="wallet">
//                 <ul class="list"></ul>
//             </div>
//         </div>
//         <div class="top-btn lf">
//             <a  class="item lf hover" href="/member/funds-apply-recharge.html"><i class="icon"></i> 充值</a>
//             <a  class="item lf hover" href="/member/funds-apply-withdraw.html" class=""><i class="icon"></i> 取款</a>
//             <a  class="item lf hover logout" data-command="logout">退出<i class="icon"></i> </a>
//             <a class="item" href="/service.html" target="_blank">
//                 <span class="text"> 在线客服</span>
//             </a>
//             <a class="item" href="/lines.html" target="_blank">
//                 <span class="text"> 线路检测</span>
//             </a>
//         </div>
//     </div>
//
// </div>
//
// </div>
// `



$(document).ready(function(){
    window.game = [
        [
            {name:"腾讯分分彩", keyword:"qqmin",type:1,statu:"new" },
            {name:"重庆时时彩",keyword:"cqssc",type:1,statu:"hot" },
            {name:"天津时时彩",keyword:"tjssc",type:1,statu:"new" },
            {name:"新疆时时彩",keyword:"xjssc",type:1,statu:"new" },
            {name:"北京时时彩",keyword:"bjssc",type:1,statu:"" },
            {name:"台湾时时彩",keyword:"twssc",type:1,statu:"" },
            {name:"幸运十分彩",keyword:"t1s600",type:1,state:"new"  },
            {name:"河内5分彩",keyword:"t1s300",type:1,state:"new"  },
            {name:"腾讯5分彩",keyword:"qq5fen",type:1,state:"new"  },
            {name:"腾讯十分彩",keyword:"qq10fen",type:1,state:"new" },
            {name:"幸运5分彩",keyword:"t1s300a",type:1,state:"new" },
            {name:"快乐2分彩",keyword:"t1s120",type:1,state:"new" },
            {name:"幸运分分彩",keyword:"t1s60a",type:1,statu:"new" },
            {name:"幸运三分彩",keyword:"t1s180a",type:1,statu:"new" },
        ],
        [
            {name:"韩国1.5分彩",keyword:"t1s90",type:2,statu:"new" },
            {name:"新加坡30秒彩",keyword:"t1s30",type:2,statu:"hot" },
            {name:"美国一分彩",keyword:"t1s60",type:2,statu:"hot" },
            {name:"东京1.5分彩",keyword:"t1s90d",type:2,statu:"hot" },
            {name:"新加坡2分彩",keyword:"sgssc",type:2,statu:"" },
            {name:"新德里1.5分彩",keyword:"t1s90a",type:2,statu:"" },
            {name:"俄罗斯1.5分彩",keyword:"t1s90b",type:2,statu:"" },
            {name:"印度1.5分彩",keyword:"t1s90c",type:2,statu:"" },
            {name:"缅甸3分彩",keyword:"t1s180",type:2,statu:"" }
        ],
        [
            {name:"纽约11选5",keyword:"t2s30",type:3,statu:"new" },
            {name:"加拿大11选5",keyword:"t2s90",type:3,statu:"hot" },
            {name:"山东11选5",keyword:"sd11x5",type:3,statu:"hot" },
            {name:"广东11选5",keyword:"gd11x5",type:3,statu:"hot" },
            {name:"江西11选5",keyword:"jx11x5",type:3,statu:"" },
            {name:"安徽11选5",keyword:"ah11x5",type:3,statu:"" },
            {name:"上海11选5",keyword:"sh11x5",type:3,statu:"" },
            {name:"辽宁11选5",keyword:"ln11x5",type:3,statu:"" }
        ],

        [
            {name:"吉隆坡快3",keyword:"t3s90",type:4,statu:"new" },
            {name:"新西兰快3",keyword:"t3s120",type:4,statu:"" },
            {name:"江苏快3",keyword:"jsk3",type:4,statu:"hot" },
            {name:"安徽快3",keyword:"ahk3",type:4,statu:"" },
            {name:"湖北快3",keyword:"hbk3",type:4,statu:"hot" },
            {name:"吉林快3",keyword:"jlk3",type:4,statu:"" },
        ],
        [
            {name:"北京快乐8",keyword:"bjkl8",type:5,statu:"hot" },
            {name:"台湾快乐8",keyword:"twkl8",type:5,statu:"hot" },
            {name:"韩国快乐8",keyword:"hgkl8",type:5,statu:"new" },
            {name:"东京快乐8",keyword:"jpkl8",type:5,statu:"" },
            {name:"新加坡快乐8",keyword:"sgkl8",type:5,statu:"" },
        ],

        [
            {name:"福彩3D",keyword:"fc3d",type:6,statu:"hot" },
            {name:"排列三",keyword:"pl3",type:6,statu:"new" },
            {name:"北京赛车PK拾",keyword:"bjpk10",type:6,statu:"hot" },
            {name:"英国120秒赛车",keyword:"t6s120",type:6,statu:"new" },
            {name:"英国180秒赛车",keyword:"t6s180",type:6,statu:"" },
            {name:"幸运飞艇",keyword:"t6s300",type:6,statu:"new" },
        ]

    ];




});


