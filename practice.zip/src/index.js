var path = require('path');
var express = require('express');
var app = express();
var router = require('./router/index');
app.set('views',path.join(__dirname,"views"))
   .set('view engine','ejs')
   .use('/',router)
   .use('/static', express.static(path.join(__dirname, 'static')))
   .listen(8080,'127.0.0.1');